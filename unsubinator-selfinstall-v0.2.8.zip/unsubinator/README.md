# Unsubinator for Gmail (self-install)

A Chrome extension that scans the sender and unsubscribe details of your Gmail and sends one-click unsubscribe requests (RFC 8058). Nothing leaves your browser except requests to Google and to the senders you choose to unsubscribe from.

This copy is for people who set up their own Google Cloud project. Full guide: https://lbysoftware.co.uk/unsubinator-public/setup.html

Quick version: create a Chrome extension OAuth client with Item ID `mokkckihdecngaghbheeecogajbpaahc`, paste its client ID into `manifest.json` in place of `YOUR_CLIENT_ID.apps.googleusercontent.com`, then load this folder from chrome://extensions with Developer mode on.

MIT licence. Made in Scotland by Look Behind You Software.
