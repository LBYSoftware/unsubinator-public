import { isSafeHttpsUrl, mergeMessage, buildQuery, sanitiseOptions } from "./lib/unsubscribe.js";

const GMAIL_API = "https://gmail.googleapis.com/gmail/v1/users/me";
const MAX_MESSAGES = 500;
const MAX_UNSUBSCRIBE_BATCH = 100;
const REQUEST_TIMEOUT_MS = 15000;
const HEADERS_WANTED = ["From", "List-Unsubscribe", "List-Unsubscribe-Post", "Authentication-Results"];

class FatalAuthError extends Error {}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Only our own extension pages may drive the background worker.
  if (sender.id !== chrome.runtime.id) return false;

  if (request?.type === "scan") {
    scan(request.options)
      .then((payload) => sendResponse({ ok: true, ...payload }))
      .catch((error) => sendResponse({ ok: false, error: publicError(error) }));
    return true;
  }
  if (request?.type === "unsubscribe") {
    bulkUnsubscribe(Array.isArray(request.senders) ? request.senders : [])
      .then((results) => sendResponse({ ok: true, results }))
      .catch((error) => sendResponse({ ok: false, error: publicError(error) }));
    return true;
  }
  if (request?.type === "signOut") {
    signOut()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: publicError(error) }));
    return true;
  }
  return false;
});

function publicError(error) {
  return error instanceof Error ? error.message : String(error);
}

function tokenFrom(result) {
  return typeof result === "string" ? result : result?.token;
}

async function getToken(interactive = true) {
  const clientId = chrome.runtime.getManifest().oauth2?.client_id || "";
  if (!clientId.endsWith(".apps.googleusercontent.com") || clientId.startsWith("YOUR_")) {
    throw new FatalAuthError(
      "Setup needed: add your own Google client ID to manifest.json, then reload the extension. Guide: https://lbysoftware.co.uk/unsubinator-public/setup.html"
    );
  }
  const token = tokenFrom(await chrome.identity.getAuthToken({ interactive }));
  if (!token) throw new FatalAuthError("Google authorization did not return an access token.");
  return token;
}

// Disconnect: revoke the grant at Google (best effort), drop the cached token
// and forget any stored scan results.
async function signOut() {
  const token = tokenFrom(await chrome.identity.getAuthToken({ interactive: false }).catch(() => null));
  if (token) {
    try {
      await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(token)}`, {
        method: "POST",
        credentials: "omit",
        referrerPolicy: "no-referrer",
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch {
      // Revocation is best effort; the cached token is still removed below.
    }
    await chrome.identity.removeCachedAuthToken({ token });
  }
  await chrome.storage.session.remove("lastScan");
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function gmailFetch(path, token, attempt = 0) {
  let response;
  try {
    response = await fetch(`${GMAIL_API}${path}`, {
      headers: { Authorization: `Bearer ${token}` },
      credentials: "omit",
      referrerPolicy: "no-referrer",
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch (error) {
    if (attempt < 3) {
      await sleep(500 * 2 ** attempt);
      return gmailFetch(path, token, attempt + 1);
    }
    throw error;
  }

  if (response.status === 401) {
    await chrome.identity.removeCachedAuthToken({ token });
    throw new FatalAuthError("Google authorization expired. Run the scan again to reconnect.");
  }
  if ((response.status === 429 || response.status >= 500) && attempt < 3) {
    await sleep(1000 * 2 ** attempt + Math.random() * 250);
    return gmailFetch(path, token, attempt + 1);
  }
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const error = new Error(body.error?.message || `Gmail API request failed (${response.status}).`);
    error.status = response.status;
    throw error;
  }
  return response.json();
}

// Scan progress lives in session storage so the popup can show it (and pick it
// back up after being closed and reopened) instead of waiting on one long reply.
const setScanState = (state) => chrome.storage.session.set({ scanState: { ...state, updatedAt: Date.now() } });

async function scan(rawOptions) {
  const { scanState } = await chrome.storage.session.get("scanState");
  if (scanState?.phase && ["connecting", "listing", "headers"].includes(scanState.phase) && Date.now() - scanState.updatedAt < 60000) {
    throw new Error("A scan is already running.");
  }
  await setScanState({ phase: "connecting" });
  try {
    const payload = await runScan(rawOptions);
    await setScanState({ phase: "done", skipped: payload.skipped, senders: payload.groups.length });
    return payload;
  } catch (error) {
    await setScanState({ phase: "error", error: publicError(error) });
    throw error;
  }
}

async function runScan(rawOptions) {
  const options = sanitiseOptions(rawOptions);
  const query = buildQuery(options);
  const token = await getToken(true);
  const ids = [];
  let pageToken;

  do {
    const params = new URLSearchParams({ q: query, maxResults: "100" });
    if (pageToken) params.set("pageToken", pageToken);
    const page = await gmailFetch(`/messages?${params}`, token);
    ids.push(...(page.messages || []).map(({ id }) => id));
    pageToken = page.nextPageToken;
    await setScanState({ phase: "listing", current: Math.min(ids.length, MAX_MESSAGES) });
  } while (pageToken && ids.length < MAX_MESSAGES);

  const selectedIds = ids.slice(0, MAX_MESSAGES);
  await setScanState({ phase: "headers", current: 0, total: selectedIds.length });
  const groups = new Map();
  const queue = [...selectedIds];
  let completed = 0;
  let skipped = 0;
  let fatal = null;

  async function worker() {
    while (queue.length && !fatal) {
      const id = queue.shift();
      const params = new URLSearchParams({ format: "metadata" });
      for (const header of HEADERS_WANTED) params.append("metadataHeaders", header);
      try {
        const message = await gmailFetch(`/messages/${encodeURIComponent(id)}?${params}`, token);
        mergeMessage(groups, message, options.excludeDomains);
      } catch (error) {
        if (error instanceof FatalAuthError) {
          fatal = error;
          return;
        }
        skipped += 1; // e.g. message deleted mid-scan; carry on with the rest
      }
      completed += 1;
      if (completed % 10 === 0 || completed === selectedIds.length) {
        await setScanState({ phase: "headers", current: completed, total: selectedIds.length });
      }
    }
  }

  await Promise.all(Array.from({ length: Math.min(6, queue.length) }, worker));
  if (fatal) throw fatal;

  const result = [...groups.values()].sort((a, b) => b.count - a.count || a.senderName.localeCompare(b.senderName));
  await chrome.storage.session.set({ lastScan: { at: Date.now(), query, options, groups: result } });
  return { groups: result, skipped };
}

// The popup only names senders. The endpoint, one-click flag and DKIM result are
// looked up here from our own scan results, never trusted from the message.
async function bulkUnsubscribe(senderEmails) {
  const { lastScan } = await chrome.storage.session.get("lastScan");
  if (!lastScan?.groups) throw new Error("Scan results have expired. Run a new scan first.");
  const bySender = new Map(lastScan.groups.map((group) => [group.senderEmail, group]));
  const emails = [...new Set(senderEmails.filter((email) => typeof email === "string"))].slice(0, MAX_UNSUBSCRIBE_BATCH);

  const results = [];
  for (let index = 0; index < emails.length; index += 1) {
    const senderEmail = emails[index];
    const method = bySender.get(senderEmail)?.method;
    let result;
    try {
      if (!method?.oneClick || !method.authenticated || !method.https) {
        throw new Error("Not a verified RFC 8058 one-click endpoint.");
      }
      const parsed = new URL(method.https);
      if (!isSafeHttpsUrl(parsed)) throw new Error("This endpoint did not pass the public HTTPS safety check.");
      const response = await fetch(parsed.href, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "List-Unsubscribe=One-Click",
        credentials: "omit",
        redirect: "error",
        referrerPolicy: "no-referrer",
        cache: "no-store",
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
      if (!response.ok) throw new Error(`Endpoint returned HTTP ${response.status}.`);
      result = { senderEmail, ok: true, status: response.status };
    } catch (error) {
      result = { senderEmail, ok: false, error: publicError(error) };
    }
    results.push(result);
    chrome.runtime.sendMessage({ type: "unsubscribeProgress", current: index + 1, total: emails.length, result }).catch(() => {});
  }
  return results;
}
