import { normaliseDomain, MAX_EXCLUDED_DOMAINS } from "./lib/unsubscribe.js";

const $ = (selector) => document.querySelector(selector);
const state = { groups: [], busy: false, excluded: [], scanning: false };

const intro = $("#intro");
const results = $("#results");
const empty = $("#empty");
const status = $("#status");
const statusText = $("#statusText");
const senders = $("#senders");
const unsubscribeButton = $("#unsubscribe");
const selectAll = $("#selectAll");
const confirmDialog = $("#confirmDialog");

chrome.runtime.onMessage.addListener((message) => {
  // Progress can arrive just after the final reply; ignore it once we are done.
  if (message.type === "unsubscribeProgress" && state.busy) {
    showStatus(`Unsubscribing ${message.current} of ${message.total}…`, true, message.current / message.total);
    paintResult(message.result);
  }
});

// Scan progress comes from session storage so it survives the popup closing.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.scanState) applyScanState(changes.scanState.newValue);
});

$("#scan").addEventListener("click", scan);
$("#signOut").addEventListener("click", signOut);
$("#scanAgain").addEventListener("click", showIntro);
$("#emptyAgain").addEventListener("click", showIntro);
unsubscribeButton.addEventListener("click", reviewSelection);
$("#confirmGo").addEventListener("click", unsubscribeSelected);
selectAll.addEventListener("change", () => {
  document.querySelectorAll(".sender-select").forEach((input) => { input.checked = selectAll.checked; });
  updateSelection();
});
senders.addEventListener("change", updateSelection);
senders.addEventListener("click", (event) => {
  const button = event.target.closest("[data-open]");
  if (button) chrome.tabs.create({ url: button.dataset.open });
});


async function send(message) {
  try {
    const response = await chrome.runtime.sendMessage(message);
    return response ?? { ok: false, error: "No response from the extension. Please try again." };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

async function scan() {
  const options = readOptions();
  state.scanning = true;
  setBusy(true);
  intro.hidden = false;
  results.hidden = true;
  empty.hidden = true;
  showStatus("Connecting to Google… approve the Google window if it appears.", true, null);
  const response = await send({ type: "scan", options });
  state.scanning = false;
  if (!response.ok) {
    if (state.busy) {
      setBusy(false);
      showError(response.error);
    }
    return;
  }
  await finishScan(response.skipped);
}

async function finishScan(skipped = 0) {
  if (!state.busy) return; // already finished by the other path
  setBusy(false);
  const { lastScan } = await chrome.storage.session.get("lastScan");
  hideStatus();
  state.groups = lastScan?.groups || [];
  $("#signOut").hidden = false;
  render();
  if (skipped) showStatus(`${skipped} message${skipped === 1 ? " was" : "s were"} skipped because they could not be read.`, false);
}

// Mirrors the background scan state onto the screen, including after reopening.
function applyScanState(scanState) {
  if (!scanState) return;
  const { phase, current, total } = scanState;
  if (phase === "connecting") {
    setBusy(true);
    showStatus("Connecting to Google… approve the Google window if it appears.", true, null);
  } else if (phase === "listing") {
    setBusy(true);
    showStatus(`Searching Gmail… ${current} matching message${current === 1 ? "" : "s"} so far.`, true, null);
  } else if (phase === "headers") {
    setBusy(true);
    showStatus(total ? `Checking unsubscribe headers: ${current} of ${total}` : "Nothing to check.", true, total ? current / total : null);
  } else if (phase === "done" && state.busy) {
    finishScan(scanState.skipped);
  } else if (phase === "error" && state.busy) {
    setBusy(false);
    showError(scanState.error);
  }
}

function render() {
  intro.hidden = true;
  if (!state.groups.length) {
    empty.hidden = false;
    return;
  }
  results.hidden = false;
  $("#senderCount").textContent = state.groups.length;
  $("#summary").textContent = `${state.groups.length} sender${state.groups.length === 1 ? "" : "s"}`;
  senders.replaceChildren(...state.groups.map(senderCard));
  updateSelection();
}

function senderCard(group) {
  const card = document.createElement("article");
  card.className = "sender";
  card.dataset.sender = group.senderEmail;

  const top = el("div", "sender-top");
  const name = el("div", "sender-name");
  name.append(el("strong", "", group.senderName), el("span", "", group.senderEmail));
  top.append(name, el("span", "count", `${group.count} msg`));

  const row = el("div", "method-row");
  if (group.method.mode === "one-click") {
    const label = el("label", "check");
    const input = document.createElement("input");
    input.type = "checkbox";
    input.className = "sender-select";
    input.dataset.sender = group.senderEmail;
    label.append(input, el("span", "badge safe", "Verified one-click"));
    row.append(label);
  } else if (group.method.mode === "web") {
    row.append(el("span", "badge review", "Web confirmation"), openButton(group.method.https, "Open & review"));
  } else {
    const link = el("a", "open-link", "Open email");
    link.href = group.method.mailto;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    row.append(el("span", "badge manual", "Email request"), link);
  }
  card.append(top, row);
  return card;
}

function openButton(url, label) {
  const button = el("button", "open-link", label);
  button.type = "button";
  button.dataset.open = url;
  return button;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function selectedGroups() {
  const selected = new Set([...document.querySelectorAll(".sender-select:checked")].map((input) => input.dataset.sender));
  return state.groups.filter((group) => selected.has(group.senderEmail));
}

function updateSelection() {
  const selected = selectedGroups().length;
  const total = document.querySelectorAll(".sender-select").length;
  unsubscribeButton.disabled = selected === 0;
  unsubscribeButton.textContent = selected ? `Show ${selected} sender${selected === 1 ? "" : "s"} the door →` : "Choose senders first";
  selectAll.checked = total > 0 && selected === total;
  selectAll.indeterminate = selected > 0 && selected < total;
}

function reviewSelection() {
  const count = selectedGroups().length;
  if (!count) return;
  $("#confirmCount").textContent = `${count} standards-based`;
  confirmDialog.showModal();
}

async function unsubscribeSelected(event) {
  event.preventDefault();
  confirmDialog.close();
  const groups = selectedGroups();
  if (!groups.length) return;
  const origins = [...new Set(groups.map((group) => `${new URL(group.method.https).origin}/*`))];
  const granted = await chrome.permissions.request({ origins });
  if (!granted) return showError("Site access was not granted, so no unsubscribe requests were sent.");

  setBusy(true);
  showStatus(`Preparing ${groups.length} unsubscribe request${groups.length === 1 ? "" : "s"}…`, true, null);
  let response;
  try {
    response = await send({ type: "unsubscribe", senders: groups.map((group) => group.senderEmail) });
  } finally {
    // Site access is only needed for the moment the requests are sent.
    await chrome.permissions.remove({ origins }).catch(() => {});
  }
  setBusy(false);
  hideStatus();
  if (!response.ok) return showError(response.error);
  const successes = response.results.filter((result) => result.ok).length;
  showStatus(`Finished: ${successes} succeeded, ${response.results.length - successes} failed.`, false);
}

function paintResult(result) {
  const card = [...document.querySelectorAll(".sender")].find((node) => node.dataset.sender === result.senderEmail);
  if (!card) return;
  card.querySelector(".result")?.remove();
  card.append(el("p", `result ${result.ok ? "ok" : "error"}`, result.ok ? "Request accepted" : result.error));
}

async function signOut() {
  const response = await send({ type: "signOut" });
  if (!response.ok) return showError(response.error);
  state.groups = [];
  results.hidden = true;
  empty.hidden = true;
  intro.hidden = false;
  $("#signOut").hidden = true;
}

async function restoreLastScan() {
  const { lastScan } = await chrome.storage.session.get("lastScan");
  if (!lastScan?.groups?.length) return;
  state.groups = lastScan.groups;
  if (lastScan.options) writeOptions(lastScan.options);
  $("#signOut").hidden = false;
  render();
}

function showIntro() {
  results.hidden = true;
  empty.hidden = true;
  intro.hidden = false;
  hideStatus();
}

function setBusy(busy) {
  state.busy = busy;
  $("#scan").disabled = busy;
  unsubscribeButton.disabled = busy || selectedGroups().length === 0;
}

// progress: a number from 0 to 1, null for "working, unknown length", undefined for no bar.
function showStatus(text, spinning = true, progress) {
  status.hidden = false;
  status.style.display = "flex";
  status.querySelector(".spinner").hidden = !spinning;
  statusText.textContent = text;
  state.statusAt = Date.now();
  state.statusBase = text;
  const bar = $("#bar");
  bar.hidden = progress === undefined;
  bar.classList.toggle("indeterminate", progress === null);
  $("#barFill").style.width = typeof progress === "number" ? `${Math.round(progress * 100)}%` : "";
}

function hideStatus() {
  status.hidden = true;
  status.style.display = "none";
}

function showError(message) {
  showStatus(message, false);
}

async function resumeScanIfRunning() {
  const { scanState } = await chrome.storage.session.get("scanState");
  const running = ["connecting", "listing", "headers"].includes(scanState?.phase) && Date.now() - scanState.updatedAt < 60000;
  if (running) applyScanState(scanState);
}

// ---- Scan options -----------------------------------------------------------

const categorySelect = $("#category");
const sinceSelect = $("#since");
const customDate = $("#customDate");
const excludeInput = $("#excludeInput");
const excludeError = $("#excludeError");

async function initOptions() {
  customDate.max = new Date().toISOString().slice(0, 10);
  sinceSelect.addEventListener("change", () => {
    customDate.hidden = sinceSelect.value !== "custom";
    if (!customDate.hidden) customDate.focus();
  });
  $("#excludeAdd").addEventListener("click", addExcluded);
  excludeInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); addExcluded(); }
  });
  try {
    const { excludeDomains } = await chrome.storage.local.get("excludeDomains");
    state.excluded = (Array.isArray(excludeDomains) ? excludeDomains : []).map(normaliseDomain).filter(Boolean);
  } catch {
    state.excluded = [];
  }
  renderExcluded();
}

function readOptions() {
  return { category: categorySelect.value, since: sinceSelect.value, customDate: customDate.value, excludeDomains: state.excluded };
}

function writeOptions(options) {
  categorySelect.value = options.category;
  sinceSelect.value = options.since;
  customDate.hidden = options.since !== "custom";
  customDate.value = options.customDate || "";
}

function addExcluded() {
  const added = [];
  for (const piece of excludeInput.value.split(/[\s,;]+/).filter(Boolean)) {
    const domain = normaliseDomain(piece);
    if (!domain) {
      excludeError.textContent = `"${piece}" doesn't look like a domain. Try something like example.com.`;
      excludeError.hidden = false;
      return;
    }
    added.push(domain);
  }
  excludeError.hidden = true;
  if (!added.length) return;
  state.excluded = [...new Set([...state.excluded, ...added])].slice(0, MAX_EXCLUDED_DOMAINS);
  excludeInput.value = "";
  saveExcluded();
}

function removeExcluded(domain) {
  state.excluded = state.excluded.filter((item) => item !== domain);
  saveExcluded();
}

function saveExcluded() {
  renderExcluded();
  chrome.storage.local.set({ excludeDomains: state.excluded }).catch(() => {});
}

function renderExcluded() {
  excludeList.replaceChildren(...state.excluded.map((domain) => {
    const item = el("li", "", domain);
    const remove = el("button", "", "×");
    remove.type = "button";
    remove.setAttribute("aria-label", `Stop excluding ${domain}`);
    remove.addEventListener("click", () => removeExcluded(domain));
    item.append(remove);
    return item;
  }));
}
const excludeList = $("#excludeList");

initOptions();
restoreLastScan();
resumeScanIfRunning();

// If nothing has changed for a while, say so rather than looking frozen.
setInterval(() => {
  if (state.busy && state.statusBase && Date.now() - state.statusAt > 12000 && !statusText.textContent.includes("Still working")) {
    statusText.textContent = `${state.statusBase} Still working, large mailboxes can take a minute.`;
  }
}, 3000);
